# Abajoo Dot Matrix Report Module

Modul ini menyediakan fungsionalitas untuk mencetak laporan dalam format dot matrix yang fleksibel dan mudah dikonfigurasi untuk Odoo 18.

## Fitur Utama

### Dokumen yang Didukung
- **Sale Order** - Pesanan penjualan
- **Purchase Order** - Pesanan pembelian  
- **Invoice** - Faktur (Customer & Vendor)
- **Stock Picking** - Pengiriman & Penerimaan barang

### Fitur Modul
- ✅ Sistem template yang fleksibel dengan variabel
- ✅ Konfigurasi mudah melalui UI
- ✅ Dukungan multiple printer configuration
- ✅ Customizable header, body, dan footer sections
- ✅ Preview functionality sebelum printing
- ✅ Test print untuk printer
- ✅ Multiple copies printing
- ✅ Template variables dengan loops dan conditionals

## Instalasi

1. Pastikan modul ini berada di direktori `custom/` Odoo Anda
2. Update daftar aplikasi di Odoo
3. Install modul "Abajoo - Dot Matrix Report for Odoo 18"
4. Konfigurasi printer dan template sesuai kebutuhan

## Konfigurasi

### 1. Konfigurasi Printer

Buka menu **Dot Matrix > Printers** dan buat konfigurasi printer baru:

#### Tipe Koneksi yang Didukung:
- **USB** - Printer terhubung via USB
- **Network** - Printer terhubung via jaringan (IP Address)
- **Serial Port** - Printer terhubung via port serial
- **Parallel Port** - Printer terhubung via port parallel
- **File Output** - Output ke file (untuk testing)

#### Konfigurasi Device Path per Platform:

**Windows:**
- Kosongkan field untuk menggunakan printer default
- Atau isi dengan nama printer Windows (misal: "EPSON TM-T88V")

**Linux:**
- USB: `/dev/usb/lp0`, `/dev/usb/lp1`, `/dev/lp0`, `/dev/lp1`
- Network: IP Address printer
- Kosongkan untuk menggunakan printer default

**macOS (Mac):**
- **USB Dot Matrix Printer**: **Kosongkan field Device Path** (direkomendasikan)
- Sistem akan menggunakan printer default yang dikonfigurasi di macOS
- Atau isi dengan nama printer dari `lpstat -p` di Terminal
- Pastikan printer sudah ditambahkan di System Preferences → Printers & Scanners

#### Pengaturan Printer:
- **Paper Width** - Lebar kertas dalam karakter (default: 80)
- **Paper Height** - Tinggi kertas dalam baris (default: 66)
- **Font Family** - Jenis font (Courier/Monospace)
- **Font Size** - Ukuran font (Small/Medium/Large)
- **Auto Cut** - Otomatis memotong kertas setelah print
- **Auto Feed** - Otomatis feed kertas
- **Print Density** - Kepadatan cetak (Light/Normal/Dark)

### 2. Konfigurasi Template

Buka menu **Dot Matrix > Templates** dan buat template baru:

#### Struktur Template:
- **Header Template** - Bagian atas dokumen
- **Body Template** - Bagian isi dokumen
- **Footer Template** - Bagian bawah dokumen

#### Variabel yang Tersedia:

**Variabel Umum:**
- `{{company_name}}` - Nama perusahaan
- `{{company_address}}` - Alamat perusahaan
- `{{company_phone}}` - Telepon perusahaan
- `{{current_date}}` - Tanggal saat ini
- `{{current_time}}` - Waktu saat ini

**Variabel Sale Order:**
- `{{order.name}}` - Nomor pesanan
- `{{order.date_order}}` - Tanggal pesanan
- `{{customer.name}}` - Nama customer
- `{{customer.address}}` - Alamat customer
- `{{total_amount}}` - Total amount
- `{{items}}` - Daftar item (gunakan loop)

**Variabel Purchase Order:**
- `{{order.name}}` - Nomor pesanan
- `{{order.date_order}}` - Tanggal pesanan
- `{{supplier.name}}` - Nama supplier
- `{{supplier.address}}` - Alamat supplier
- `{{total_amount}}` - Total amount
- `{{items}}` - Daftar item (gunakan loop)

**Variabel Invoice:**
- `{{invoice.name}}` - Nomor invoice
- `{{invoice.date}}` - Tanggal invoice
- `{{invoice.due_date}}` - Tanggal jatuh tempo
- `{{partner.name}}` - Nama partner
- `{{partner.address}}` - Alamat partner
- `{{total_amount}}` - Total amount
- `{{items}}` - Daftar item (gunakan loop)

**Variabel Stock Picking:**
- `{{picking.name}}` - Nomor picking
- `{{picking.date}}` - Tanggal picking
- `{{picking.picking_type}}` - Jenis picking
- `{{partner.name}}` - Nama partner
- `{{partner.address}}` - Alamat partner
- `{{total_items}}` - Total item
- `{{items}}` - Daftar item (gunakan loop)

#### Contoh Template Sale Order:

```
SALE ORDER
==========================================
Order: {{order.name}}          Date: {{order.date_order}}
Customer: {{customer.name}}
Address: {{customer.address}}
Phone: {{customer.phone}}

ITEMS:
----------------------------------------
{% for item in items %}
{{item.name}}
  Qty: {{item.qty}} x {{item.price}} = {{item.subtotal}}
  {{item.description}}
{% endfor %}

----------------------------------------
Subtotal: {{untaxed_amount}}
Tax: {{tax_amount}}
TOTAL: {{total_amount}} {{currency_symbol}}
==========================================
Thank you for your business!
```

## Penggunaan

### 1. Print dari Dokumen

Setelah modul terinstall, setiap dokumen (Sale Order, Purchase Order, Invoice, Stock Picking) akan memiliki:

- **Tombol "Print Dot Matrix"** di action menu
- **Menu "Print Dot Matrix"** di dropdown menu

### 2. Wizard Print

Ketika memilih print dot matrix, wizard akan muncul dengan opsi:

- **Template** - Pilih template yang akan digunakan
- **Printer** - Pilih printer yang akan digunakan
- **Copies** - Jumlah copy yang akan dicetak
- **Preview** - Preview hasil sebelum print

### 3. Test Print

Untuk memastikan printer berfungsi dengan baik:

1. Buka menu **Dot Matrix > Printers**
2. Pilih printer yang ingin ditest
3. Klik tombol **"Test Print"**
4. Periksa hasil cetak

## Troubleshooting

### Printer Tidak Terdeteksi
1. Pastikan driver printer sudah terinstall
2. Periksa koneksi USB/Network
3. Test dengan "File Output" terlebih dahulu

### Template Tidak Muncul
1. Pastikan template sudah dibuat untuk jenis dokumen yang sesuai
2. Periksa status "Active" pada template
3. Pastikan template memiliki printer yang terkonfigurasi

### Print Gagal
1. Periksa status printer (online/offline)
2. Test print terlebih dahulu
3. Periksa log error di Odoo

### Troubleshooting Khusus Platform

**macOS (Mac):**
1. **Printer USB tidak terdeteksi:**
   - Pastikan printer sudah ditambahkan di System Preferences → Printers & Scanners
   - Install driver printer jika diperlukan
   - Test dengan perintah: `echo "test" | lp` di Terminal

2. **Device Path untuk USB Dot Matrix:**
   - **Kosongkan field Device Path** (paling direkomendasikan)
   - Sistem akan otomatis menggunakan printer default
   - Jika perlu spesifik, gunakan nama printer dari `lpstat -p`

3. **Permission issues:**
   - Pastikan Odoo memiliki akses ke printer
   - Cek dengan: `ls -la /dev/usb/lp*` di Terminal

## File Output untuk Testing

Untuk testing tanpa printer fisik, gunakan tipe koneksi "File Output". File akan disimpan di:
- Linux/Mac: `/tmp/odoo_dot_matrix/`
- Windows: `C:\temp\odoo_dot_matrix\`

## Customization

### Menambah Jenis Dokumen Baru

1. Tambahkan document type baru di model `dot.matrix.template`
2. Buat method `_prepare_[document_type]_data`
3. Tambahkan action di dokumen yang sesuai
4. Buat template default di data XML

### Menambah Variabel Baru

1. Tambahkan field baru di method `_prepare_data`
2. Update template untuk menggunakan variabel baru
3. Update sample data untuk testing

## Support

Untuk dukungan teknis, silakan hubungi:
- Email: support@abajoo.co.id
- Website: https://abajoo.co.id

## License

Modul ini dilisensikan di bawah LGPL-3 License. 