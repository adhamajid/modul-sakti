from odoo import http
from odoo.http import request
import urllib.parse
import logging

_logger = logging.getLogger(__name__)


class DotMatrixController(http.Controller):

    @http.route('/web/content/dot_matrix_download', type='http', auth='user')
    def download_dot_matrix(self, filename=None, content=None, **kwargs):
        """Download dot matrix report as text file"""
        try:
            if not filename or not content:
                return request.not_found()
            
            # Decode content if it's URL encoded
            content = urllib.parse.unquote(content)
            
            # Create response with proper headers
            response = request.make_response(
                content.encode('utf-8'),
                headers=[
                    ('Content-Type', 'text/plain; charset=utf-8'),
                    ('Content-Disposition', f'attachment; filename="{filename}"'),
                    ('Content-Length', str(len(content.encode('utf-8')))),
                ]
            )
            
            return response
            
        except Exception as e:
            return request.not_found() 