from odoo import models, fields, api, _
from odoo.exceptions import UserError


class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_print_dot_matrix_wizard(self):
        """Open print wizard for dot matrix printing"""
        self.ensure_one()
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Print Dot Matrix Report'),
            'res_model': 'dot.matrix.report.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_document_type': 'account.move',
                'default_document_id': self.id,
                'default_document_name': self.name,
            }
        } 