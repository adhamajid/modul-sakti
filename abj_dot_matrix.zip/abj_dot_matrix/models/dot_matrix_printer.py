from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import platform
import os
import subprocess
import tempfile
import logging

_logger = logging.getLogger(__name__)


class DotMatrixPrinter(models.Model):
    _name = 'dot.matrix.printer'
    _description = 'Dot Matrix Printer Configuration'
    _order = 'name'

    name = fields.Char('Printer Name', required=True)
    active = fields.Boolean('Active', default=True)
    
    # Connection settings
    connection_type = fields.Selection([
        ('usb', 'USB'),
        ('network', 'Network'),
        ('serial', 'Serial Port'),
        ('parallel', 'Parallel Port'),
        ('file', 'File Output'),
    ], string='Connection Type', required=True, default='usb')
    
    device_path = fields.Char('Device Path/Port', help="USB device path, IP address, or port name")
    network_port = fields.Integer('Network Port', default=9100, help="Port for network printers")
    
    # Printer settings
    paper_width = fields.Integer('Paper Width (chars)', default=80)
    paper_height = fields.Integer('Paper Height (lines)', default=66)
    
    # Font settings
    default_font_family = fields.Selection([
        ('courier', 'Courier'),
        ('monospace', 'Monospace'),
    ], string='Default Font Family', default='courier')
    
    default_font_size = fields.Selection([
        ('small', 'Small (8pt)'),
        ('medium', 'Medium (10pt)'),
        ('large', 'Large (12pt)'),
    ], string='Default Font Size', default='medium')
    
    # Print settings
    auto_cut = fields.Boolean('Auto Cut Paper', default=True)
    auto_feed = fields.Boolean('Auto Feed', default=True)
    print_density = fields.Selection([
        ('light', 'Light'),
        ('normal', 'Normal'),
        ('dark', 'Dark'),
    ], string='Print Density', default='normal')
    
    # Test print
    test_print_text = fields.Text('Test Print Text', default="""Dot Matrix Printer Test
================================
Printer: {{printer_name}}
Date: {{date}}
Time: {{time}}
Status: OK

This is a test print to verify
the printer configuration is
working correctly.

End of test.
""")
    
    # Status
    is_default = fields.Boolean('Default Printer', default=False)
    last_test_date = fields.Datetime('Last Test Date', readonly=True)
    test_status = fields.Selection([
        ('not_tested', 'Not Tested'),
        ('success', 'Success'),
        ('failed', 'Failed'),
    ], string='Test Status', default='not_tested')
    
    notes = fields.Text('Notes')
    
    _sql_constraints = [
        ('name_uniq', 'unique(name)', 'Printer name must be unique!')
    ]

    @api.constrains('is_default')
    def _check_default_printer(self):
        """Ensure only one default printer per connection type"""
        for printer in self:
            if printer.is_default:
                other_defaults = self.search([
                    ('id', '!=', printer.id),
                    ('is_default', '=', True),
                    ('connection_type', '=', printer.connection_type)
                ])
                if other_defaults:
                    raise ValidationError(_('Only one default printer allowed per connection type.'))

    def action_test_print(self):
        """Test print functionality"""
        self.ensure_one()
        
        try:
            # Generate test content
            test_content = self._generate_test_content()
            
            # Send to printer
            success = self._send_to_printer(test_content)
            
            if success:
                self.write({
                    'last_test_date': fields.Datetime.now(),
                    'test_status': 'success'
                })
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Success'),
                        'message': _('Test print sent successfully to %s') % self.name,
                        'type': 'success',
                    }
                }
            else:
                self.write({
                    'last_test_date': fields.Datetime.now(),
                    'test_status': 'failed'
                })
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Error'),
                        'message': _('Failed to send test print to %s') % self.name,
                        'type': 'danger',
                    }
                }
        except Exception as e:
            self.write({
                'last_test_date': fields.Datetime.now(),
                'test_status': 'failed'
            })
            raise ValidationError(_('Test print failed: %s') % str(e))

    def _generate_test_content(self):
        """Generate test print content"""
        from datetime import datetime
        
        test_data = {
            'printer_name': self.name,
            'date': datetime.now().strftime('%Y-%m-%d'),
            'time': datetime.now().strftime('%H:%M:%S'),
        }
        
        # Simple variable replacement
        content = self.test_print_text
        for key, value in test_data.items():
            content = content.replace(f'{{{{{key}}}}}', str(value))
        
        return content

    def _send_to_printer(self, content):
        """Send content to printer based on connection type"""
        if self.connection_type == 'file':
            return self._send_to_file(content)
        elif self.connection_type == 'network':
            return self._send_to_network(content)
        elif self.connection_type == 'usb':
            return self._send_to_usb(content)
        else:
            # For other connection types, just return True for now
            # In real implementation, you would add proper drivers
            return True

    def _send_to_file(self, content):
        """Send content to file (for testing/debugging)"""
        try:
            from datetime import datetime
            
            # Create output directory if it doesn't exist
            output_dir = '/tmp/odoo_dot_matrix'
            os.makedirs(output_dir, exist_ok=True)
            
            # Create filename with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{output_dir}/{self.name}_{timestamp}.txt"
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(content)
            
            _logger.info(f"File saved to: {filename}")
            return True
        except Exception as e:
            _logger.error(f"Failed to write to file: {e}")
            return False

    def _send_to_network(self, content):
        """Send content to network printer"""
        try:
            import socket
            
            if not self.device_path:
                _logger.error("No device path specified for network printer")
                return False
            
            # Convert content to bytes
            content_bytes = content.encode('utf-8')
            
            # Create socket connection
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((self.device_path, self.network_port))
            sock.send(content_bytes)
            sock.close()
            
            _logger.info(f"Successfully sent to network printer: {self.device_path}:{self.network_port}")
            return True
        except Exception as e:
            _logger.error(f"Failed to send to network printer: {e}")
            return False

    def _send_to_usb(self, content):
        """Send content to USB printer - Cross-platform implementation"""
        try:
            system = platform.system().lower()
            if system == 'windows':
                return self._send_to_usb_windows(content)
            elif system == 'linux':
                return self._send_to_usb_linux(content)
            elif system == 'darwin':  # macOS
                return self._send_to_usb_mac(content)
            else:
                # Fallback to file output for unknown systems
                return self._send_to_file(content)
                
        except Exception as e:
            _logger.error(f"Failed to send to USB printer: {e}")
            return False

    def _send_to_usb_windows(self, content):
        """Send content to USB printer on Windows"""
        temp_file_path = None
        try:
            # Create temporary file with content
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as temp_file:
                temp_file.write(content)
                temp_file_path = temp_file.name
            
            # Use Windows copy command to send to printer
            # This requires the printer to be configured in Windows
            if self.device_path:
                # If device_path is a printer name, use it directly
                printer_name = self.device_path
            else:
                # Use default printer
                printer_name = "Microsoft Print to PDF"  # Fallback
            
            try:
                # Method 1: Try using copy command (works with some printers)
                result = subprocess.run([
                    'cmd', '/c', 'copy', temp_file_path, printer_name
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    _logger.info(f"Successfully sent to Windows printer: {printer_name}")
                    return True
                    
            except subprocess.TimeoutExpired:
                _logger.warning(f"Timeout sending to Windows printer: {printer_name}")
            
            # Method 2: Fallback to file output
            _logger.info(f"Falling back to file output for Windows printer: {printer_name}")
            return self._send_to_file(content)
            
        except Exception as e:
            _logger.error(f"Failed to send to Windows USB printer: {e}")
            return False
        finally:
            # Clean up temporary file
            if temp_file_path:
                try:
                    os.unlink(temp_file_path)
                except:
                    pass

    def _send_to_usb_linux(self, content):
        """Send content to USB printer on Linux"""
        try:            
            # Common USB printer device paths
            possible_paths = [
                self.device_path,  # User specified path
                '/dev/usb/lp0',
                '/dev/usb/lp1',
                '/dev/lp0',
                '/dev/lp1',
            ]
            
            # Try each possible path
            for device_path in possible_paths:
                if not device_path:
                    continue
                    
                if os.path.exists(device_path):
                    try:
                        with open(device_path, 'wb') as usb_printer:
                            # Use ASCII encoding for dot matrix printers
                            usb_printer.write(content.encode('ascii', errors='replace'))
                        _logger.info(f"Successfully sent to Linux USB printer: {device_path}")
                        return True
                    except PermissionError:
                        _logger.error(f"Permission denied for USB device: {device_path}")
                        _logger.info("Try running Odoo with sudo or add user to lp group")
                        continue
                    except Exception as e:
                        _logger.error(f"Failed to write to USB device {device_path}: {e}")
                        continue
            
            # If no USB device found, fallback to file output
            _logger.info("No USB printer found, falling back to file output")
            return self._send_to_file(content)
            
        except Exception as e:
            _logger.error(f"Failed to send to Linux USB printer: {e}")
            return False

    def _send_to_usb_mac(self, content):
        """Send content to USB printer on macOS"""
        temp_file_path = None
        try:
            # Create temporary file with content
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as temp_file:
                temp_file.write(content)
                temp_file_path = temp_file.name
            
            # Use CUPS lp command to print
            try:
                if self.device_path:
                    # Use specified printer
                    result = subprocess.run([
                        'lp', '-d', self.device_path, temp_file_path
                    ], capture_output=True, text=True, timeout=30)
                else:
                    # Use default printer
                    result = subprocess.run([
                        'lp', temp_file_path
                    ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    _logger.info(f"Successfully sent to macOS printer via CUPS")
                    return True
                    
            except subprocess.TimeoutExpired:
                _logger.warning("Timeout sending to macOS printer")
            except FileNotFoundError:
                _logger.error("CUPS lp command not found")
            
            # Fallback to file output
            _logger.info("Falling back to file output for macOS printer")
            return self._send_to_file(content)
            
        except Exception as e:
            _logger.error(f"Failed to send to macOS USB printer: {e}")
            return False
        finally:
            # Clean up temporary file
            if temp_file_path:
                try:
                    os.unlink(temp_file_path)
                except:
                    pass

    def print_report(self, content, template=None):
        """Print report content using this printer"""
        try:
            # Apply printer-specific formatting
            formatted_content = self._format_content(content, template)
            
            # Send to printer
            success = self._send_to_printer(formatted_content)
            
            if success:
                _logger.info(f"Report printed successfully on {self.name}")
            else:
                _logger.error(f"Failed to print report on {self.name}")
            
            return success
        except Exception as e:
            _logger.error(f"Error printing report on {self.name}: {e}")
            return False

    def _format_content(self, content, template=None):
        """Format content according to printer settings"""
        # Apply printer-specific formatting
        formatted = content
        
        # Add printer control codes if needed
        if self.auto_cut:
            formatted += "\n\n\n\n\n"  # Feed paper before cutting
        
        if self.auto_feed:
            formatted += "\n\n"  # Extra line feeds
        
        return formatted

    @api.model
    def get_default_printer(self):
        """Get default printer"""
        return self.search([('is_default', '=', True)], limit=1)

    def action_set_default(self):
        """Set this printer as default"""
        self.ensure_one()
        
        # Unset other default printers of same type
        other_defaults = self.search([
            ('id', '!=', self.id),
            ('is_default', '=', True),
            ('connection_type', '=', self.connection_type)
        ])
        other_defaults.write({'is_default': False})
        
        # Set this printer as default
        self.write({'is_default': True})
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Success'),
                'message': _('%s is now the default printer') % self.name,
                'type': 'success',
            }
        }

    def action_detect_printers(self):
        """Detect available printers on the system"""
        self.ensure_one()
        
        try:
            import platform
            system = platform.system().lower()
            
            if system == 'windows':
                printers = self._detect_windows_printers()
            elif system == 'linux':
                printers = self._detect_linux_printers()
            elif system == 'darwin':  # macOS
                printers = self._detect_mac_printers()
            else:
                printers = []
            
            if printers:
                message = _('Detected printers: %s') % ', '.join(printers)
            else:
                message = _('No printers detected. Please check your printer configuration.')
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Printer Detection'),
                    'message': message,
                    'type': 'info',
                }
            }
            
        except Exception as e:
            _logger.error(f"Failed to detect printers: {e}")
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Error'),
                    'message': _('Failed to detect printers: %s') % str(e),
                    'type': 'danger',
                }
            }

    def _detect_windows_printers(self):
        """Detect printers on Windows"""
        try:
            import subprocess
            
            # Use wmic to list printers
            result = subprocess.run([
                'wmic', 'printer', 'get', 'name'
            ], capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')[1:]  # Skip header
                printers = [line.strip() for line in lines if line.strip()]
                _logger.info(f"Detected Windows printers: {printers}")
                return printers
                
        except Exception as e:
            _logger.error(f"Failed to detect Windows printers: {e}")
        
        return []

    def _detect_linux_printers(self):
        """Detect printers on Linux"""
        try:
            import subprocess
            import os
            
            printers = []
            
            # Method 1: Use lpstat command
            try:
                result = subprocess.run([
                    'lpstat', '-p'
                ], capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    for line in lines:
                        if line.startswith('printer'):
                            parts = line.split()
                            if len(parts) >= 2:
                                printers.append(parts[1])
            except:
                pass
            
            # Method 2: Check common USB device paths
            usb_paths = ['/dev/usb/lp0', '/dev/usb/lp1', '/dev/lp0', '/dev/lp1']
            for path in usb_paths:
                if os.path.exists(path):
                    printers.append(f"USB Device: {path}")
            
            _logger.info(f"Detected Linux printers: {printers}")
            return printers
            
        except Exception as e:
            _logger.error(f"Failed to detect Linux printers: {e}")
        
        return []

    def _detect_mac_printers(self):
        """Detect printers on macOS"""
        try:
            import subprocess
            
            # Use lpstat command
            result = subprocess.run([
                'lpstat', '-p'
            ], capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                printers = []
                for line in lines:
                    if line.startswith('printer'):
                        parts = line.split()
                        if len(parts) >= 2:
                            printers.append(parts[1])
                
                _logger.info(f"Detected macOS printers: {printers}")
                return printers
                
        except Exception as e:
            _logger.error(f"Failed to detect macOS printers: {e}")
        
        return [] 