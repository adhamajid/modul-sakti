from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import re
import json


class DotMatrixTemplate(models.Model):
    _name = 'dot.matrix.template'
    _description = 'Dot Matrix Template'
    _order = 'name'

    name = fields.Char('Template Name', required=True)
    active = fields.Boolean('Active', default=True)
    document_type = fields.Selection([
        ('sale.order', 'Sale Order'),
        ('purchase.order', 'Purchase Order'),
        ('account.move', 'Invoice'),
        ('stock.picking', 'Stock Picking'),
    ], string='Document Type', required=True)
    
    printer_id = fields.Many2one('dot.matrix.printer', string='Default Printer')
    paper_width = fields.Integer('Paper Width (chars)', default=80)
    paper_height = fields.Integer('Paper Height (lines)', default=66)
    
    # Template sections
    header_template = fields.Text('Header Template', help="Template for header section")
    body_template = fields.Text('Body Template', help="Template for body section")
    footer_template = fields.Text('Footer Template', help="Template for footer section")
    
    # Configuration
    font_family = fields.Selection([
        ('courier', 'Courier'),
        ('monospace', 'Monospace'),
    ], string='Font Family', default='courier')
    
    font_size = fields.Selection([
        ('small', 'Small (8pt)'),
        ('medium', 'Medium (10pt)'),
        ('large', 'Large (12pt)'),
    ], string='Font Size', default='medium')
    
    # Variables available for this template
    variable_ids = fields.One2many('dot.matrix.variable', 'template_id', string='Available Variables')
    
    # Sample data for preview
    sample_data = fields.Text('Sample Data (JSON)', help="Sample data for preview in JSON format")
    
    # Template preview
    preview_text = fields.Text('Preview', readonly=True, compute='_compute_preview')
    
    _sql_constraints = [
        ('name_uniq', 'unique(name)', 'Template name must be unique!')
    ]

    @api.depends('header_template', 'body_template', 'footer_template', 'sample_data')
    def _compute_preview(self):
        for template in self:
            if template.sample_data:
                try:
                    sample_data = json.loads(template.sample_data)
                    preview = self._render_template(template, sample_data)
                    template.preview_text = preview
                except Exception as e:
                    template.preview_text = "Error generating preview: %s" % str(e)
            else:
                template.preview_text = "No sample data available"

    @api.model
    def _render_template(self, template, data):
        """Render template with given data"""
        result = ""
        
        # Render header
        if template.header_template:
            result += self._render_section(template.header_template, data) + "\n"
        
        # Render body
        if template.body_template:
            result += self._render_section(template.body_template, data) + "\n"
        
        # Render footer
        if template.footer_template:
            result += self._render_section(template.footer_template, data)
        
        return result

    @api.model
    def _render_section(self, template_text, data):
        """Render a section of the template"""
        if not template_text:
            return ""

        # Proses loop terlebih dahulu agar placeholder di dalam loop bisa di-render
        result = self._process_loops(template_text, data)

        # Proses conditional
        result = self._process_conditionals(result, data)

        # Fungsi rekursif untuk mencari dan mengganti placeholder dengan dot notation, misal {{order.name}}
        def replace_dot_notation(match):
            expr = match.group(1).strip()
            value = self._get_value_from_data(expr, data)
            return str(value) if value is not None else ""

        # Ganti semua {{ ... }} dengan value yang sesuai, support dot notation
        result = re.sub(r"\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}", replace_dot_notation, result)

        return result

    def _get_value_from_data(self, expr, data):
        """Ambil value dari data dict dengan support dot notation, misal 'order.name'"""
        keys = expr.split('.')
        val = data
        for key in keys:
            if isinstance(val, dict):
                val = val.get(key)
            elif isinstance(val, list):
                try:
                    idx = int(key)
                    val = val[idx]
                except (ValueError, IndexError):
                    return None
            else:
                return None
            if val is None:
                return None
        return val

    @api.model
    def _process_loops(self, text, data):
        """Process loop statements in template"""
        # Pola: {% for item in items %} ... {% endfor %}
        loop_pattern = r'\{%\s*for\s+(\w+)\s+in\s+([a-zA-Z0-9_\.]+)\s*%\}(.*?)\{%\s*endfor\s*%\}'

        def replace_loop(match):
            var_name = match.group(1)
            list_expr = match.group(2)
            loop_content = match.group(3)

            items = self._get_value_from_data(list_expr, data)
            if isinstance(items, list):
                result = ""
                for item in items:
                    # Buat context baru dengan variable loop
                    # Gunakan copy mendalam agar nested loop/variable tidak saling overwrite
                    if isinstance(data, dict):
                        loop_data = dict(data)
                    else:
                        loop_data = {}
                    loop_data[var_name] = item
                    # Render isi loop dengan context baru
                    result += self._render_section(loop_content, loop_data)
                return result
            return ""

        # Gunakan re.sub untuk mendukung nested loop (rekursif)
        prev_text = None
        while prev_text != text:
            prev_text = text
            text = re.sub(loop_pattern, replace_loop, text, flags=re.DOTALL)
        return text

    @api.model
    def _process_conditionals(self, text, data):
        """Process conditional statements in template"""
        # Pola: {% if condition %} ... {% endif %}
        if_pattern = r'\{%\s*if\s+([a-zA-Z0-9_\.]+)\s*%\}(.*?)\{%\s*endif\s*%\}'

        def replace_conditional(match):
            condition_expr = match.group(1)
            content = match.group(2)
            cond_value = self._get_value_from_data(condition_expr, data)
            if cond_value:
                return self._render_section(content, data)
            return ""

        # Gunakan re.sub untuk mendukung nested if (rekursif)
        prev_text = None
        while prev_text != text:
            prev_text = text
            text = re.sub(if_pattern, replace_conditional, text, flags=re.DOTALL)
        return text

    def generate_report(self, record):
        """Generate report for a specific record"""
        data = self._prepare_data(record)
        return self._render_template(self, data)

    @api.model
    def _prepare_data(self, record):
        """Prepare data for template rendering based on document type"""
        if self.document_type == 'sale.order':
            return self._prepare_sale_order_data(record)
        elif self.document_type == 'purchase.order':
            return self._prepare_purchase_order_data(record)
        elif self.document_type == 'account.move':
            return self._prepare_invoice_data(record)
        elif self.document_type == 'stock.picking':
            return self._prepare_stock_picking_data(record)
        return {}

    @api.model
    def _prepare_sale_order_data(self, order):
        """Prepare data for sale order"""
        return {
            'order': {
                'name': order.name,
                'date_order': order.date_order.strftime('%Y-%m-%d') if order.date_order else '',
                'partner_ref': '',
                'amount_total': order.amount_total,
                'currency_symbol': order.currency_id.symbol,
            },
            'customer': {
                'name': order.partner_id.name,
                'street': order.partner_id.street or '',
                'city': order.partner_id.city or '',
                'phone': order.partner_id.phone or '',
                'email': order.partner_id.email or '',
            },
            'items': [{
                'name': line.product_id.name,
                'description': line.name,
                'qty': line.product_uom_qty,
                'price': line.price_unit,
                'subtotal': line.price_subtotal,
            } for line in order.order_line],
            'total_amount': order.amount_total,
            'tax_amount': order.amount_tax,
            'untaxed_amount': order.amount_untaxed,
        }

    @api.model
    def _prepare_purchase_order_data(self, order):
        """Prepare data for purchase order"""
        return {
            'order': {
                'name': order.name,
                'date_order': order.date_order.strftime('%Y-%m-%d') if order.date_order else '',
                'partner_ref': order.partner_ref or '',
                'amount_total': order.amount_total,
                'currency_symbol': order.currency_id.symbol,
            },
            'supplier': {
                'name': order.partner_id.name,
                'street': order.partner_id.street or '',
                'city': order.partner_id.city or '',
                'phone': order.partner_id.phone or '',
                'email': order.partner_id.email or '',
            },
            'items': [{
                'name': line.product_id.name,
                'description': line.name,
                'qty': line.product_qty,
                'price': line.price_unit,
                'subtotal': line.price_subtotal,
            } for line in order.order_line],
            'total_amount': order.amount_total,
            'tax_amount': order.amount_tax,
            'untaxed_amount': order.amount_untaxed,
        }

    @api.model
    def _prepare_invoice_data(self, invoice):
        """Prepare data for invoice"""
        return {
            'invoice': {
                'name': invoice.name,
                'date': invoice.invoice_date.strftime('%Y-%m-%d') if invoice.invoice_date else '',
                'due_date': invoice.invoice_due_date.strftime('%Y-%m-%d') if invoice.invoice_due_date else '',
                'amount_total': invoice.amount_total,
                'currency_symbol': invoice.currency_id.symbol,
                'type': invoice.move_type,
            },
            'partner': {
                'name': invoice.partner_id.name,
                'street': invoice.partner_id.street or '',
                'city': invoice.partner_id.city or '',
                'phone': invoice.partner_id.phone or '',
                'email': invoice.partner_id.email or '',
            },
            'items': [{
                'name': line.product_id.name if line.product_id else '',
                'description': line.name,
                'qty': line.quantity,
                'price': line.price_unit,
                'subtotal': line.price_subtotal,
            } for line in invoice.invoice_line_ids],
            'total_amount': invoice.amount_total,
            'tax_amount': invoice.amount_tax,
            'untaxed_amount': invoice.amount_untaxed,
        }

    @api.model
    def _prepare_stock_picking_data(self, picking):
        """Prepare data for stock picking"""
        return {
            'picking': {
                'name': picking.name,
                'date': picking.scheduled_date.strftime('%Y-%m-%d') if picking.scheduled_date else '',
                'picking_type': picking.picking_type_id.name,
                'origin': picking.origin or '',
            },
            'partner': {
                'name': picking.partner_id.name if picking.partner_id else '',
                'street': picking.partner_id.street or '',
                'city': picking.partner_id.city or '',
                'phone': picking.partner_id.phone or '',
            },
            'items': [{
                'name': line.product_id.name,
                'description': line.product_id.description_sale or '',
                'qty': line.product_uom_qty,
                'qty_done': line.quantity_done,
                'uom': line.product_uom.name,
            } for line in picking.move_ids_without_package],
            'total_items': len(picking.move_ids_without_package),
        }

    @api.model
    def get_default_template(self, document_type):
        """Get default template for document type"""
        return self.search([
            ('document_type', '=', document_type),
            ('active', '=', True)
        ], limit=1)