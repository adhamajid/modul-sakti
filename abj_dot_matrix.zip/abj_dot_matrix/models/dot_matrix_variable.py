from odoo import models, fields, api, _


class DotMatrixVariable(models.Model):
    _name = 'dot.matrix.variable'
    _description = 'Dot Matrix Template Variable'
    _order = 'sequence, name'

    name = fields.Char('Variable Name', required=True)
    description = fields.Text('Description')
    sequence = fields.Integer('Sequence', default=10)
    
    template_id = fields.Many2one('dot.matrix.template', string='Template', required=True, ondelete='cascade')
    
    # Variable type and format
    variable_type = fields.Selection([
        ('text', 'Text'),
        ('number', 'Number'),
        ('date', 'Date'),
        ('datetime', 'DateTime'),
        ('currency', 'Currency'),
        ('boolean', 'Boolean'),
    ], string='Variable Type', default='text')
    
    # Format options
    date_format = fields.Char('Date Format', default='%Y-%m-%d', help="Python date format string")
    number_format = fields.Char('Number Format', default='%.2f', help="Python number format string")
    currency_format = fields.Char('Currency Format', default='%.2f', help="Currency format string")
    
    # Default value
    default_value = fields.Char('Default Value')
    
    # Usage example
    usage_example = fields.Char('Usage Example', compute='_compute_usage_example')
    
    # Available for document types
    available_for = fields.Selection([
        ('all', 'All Documents'),
        ('sale.order', 'Sale Order Only'),
        ('purchase.order', 'Purchase Order Only'),
        ('account.move', 'Invoice Only'),
        ('stock.picking', 'Stock Picking Only'),
    ], string='Available For', default='all')

    @api.depends('name', 'variable_type')
    def _compute_usage_example(self):
        for variable in self:
            if variable.variable_type == 'date':
                variable.usage_example = f"{{{{{variable.name}}}}}"
            elif variable.variable_type == 'number':
                variable.usage_example = f"{{{{{variable.name}}}}}"
            elif variable.variable_type == 'currency':
                variable.usage_example = f"{{{{{variable.name}}}}}"
            else:
                variable.usage_example = f"{{{{{variable.name}}}}}"

    @api.model
    def get_variables_for_document_type(self, document_type):
        """Get available variables for a specific document type"""
        return self.search([
            '|',
            ('available_for', '=', 'all'),
            ('available_for', '=', document_type)
        ])

    def get_formatted_value(self, value):
        """Get formatted value based on variable type"""
        if not value:
            return self.default_value or ""
        
        try:
            if self.variable_type == 'date':
                if hasattr(value, 'strftime'):
                    return value.strftime(self.date_format)
                return str(value)
            elif self.variable_type == 'number':
                return self.number_format % float(value)
            elif self.variable_type == 'currency':
                return self.currency_format % float(value)
            elif self.variable_type == 'boolean':
                return "Yes" if value else "No"
            else:
                return str(value)
        except:
            return str(value) if value else ""

    @api.model
    def create_default_variables(self, template):
        """Create default variables for a template based on document type"""
        default_variables = self._get_default_variables(template.document_type)
        
        for var_data in default_variables:
            var_data['template_id'] = template.id
            self.create(var_data)

    def _get_default_variables(self, document_type):
        """Get default variables for document type"""
        base_variables = [
            {
                'name': 'company_name',
                'description': 'Company name',
                'variable_type': 'text',
                'sequence': 10,
                'available_for': 'all',
            },
            {
                'name': 'company_address',
                'description': 'Company address',
                'variable_type': 'text',
                'sequence': 20,
                'available_for': 'all',
            },
            {
                'name': 'company_phone',
                'description': 'Company phone',
                'variable_type': 'text',
                'sequence': 30,
                'available_for': 'all',
            },
            {
                'name': 'current_date',
                'description': 'Current date',
                'variable_type': 'date',
                'sequence': 40,
                'available_for': 'all',
            },
            {
                'name': 'current_time',
                'description': 'Current time',
                'variable_type': 'datetime',
                'sequence': 50,
                'available_for': 'all',
            },
        ]
        
        if document_type == 'sale.order':
            base_variables.extend([
                {
                    'name': 'order_name',
                    'description': 'Sale order number',
                    'variable_type': 'text',
                    'sequence': 100,
                    'available_for': 'sale.order',
                },
                {
                    'name': 'order_date',
                    'description': 'Order date',
                    'variable_type': 'date',
                    'sequence': 110,
                    'available_for': 'sale.order',
                },
                {
                    'name': 'customer_name',
                    'description': 'Customer name',
                    'variable_type': 'text',
                    'sequence': 120,
                    'available_for': 'sale.order',
                },
                {
                    'name': 'customer_address',
                    'description': 'Customer address',
                    'variable_type': 'text',
                    'sequence': 130,
                    'available_for': 'sale.order',
                },
                {
                    'name': 'total_amount',
                    'description': 'Total amount',
                    'variable_type': 'currency',
                    'sequence': 140,
                    'available_for': 'sale.order',
                },
            ])
        elif document_type == 'purchase.order':
            base_variables.extend([
                {
                    'name': 'order_name',
                    'description': 'Purchase order number',
                    'variable_type': 'text',
                    'sequence': 100,
                    'available_for': 'purchase.order',
                },
                {
                    'name': 'order_date',
                    'description': 'Order date',
                    'variable_type': 'date',
                    'sequence': 110,
                    'available_for': 'purchase.order',
                },
                {
                    'name': 'supplier_name',
                    'description': 'Supplier name',
                    'variable_type': 'text',
                    'sequence': 120,
                    'available_for': 'purchase.order',
                },
                {
                    'name': 'supplier_address',
                    'description': 'Supplier address',
                    'variable_type': 'text',
                    'sequence': 130,
                    'available_for': 'purchase.order',
                },
                {
                    'name': 'total_amount',
                    'description': 'Total amount',
                    'variable_type': 'currency',
                    'sequence': 140,
                    'available_for': 'purchase.order',
                },
            ])
        elif document_type == 'account.move':
            base_variables.extend([
                {
                    'name': 'invoice_name',
                    'description': 'Invoice number',
                    'variable_type': 'text',
                    'sequence': 100,
                    'available_for': 'account.move',
                },
                {
                    'name': 'invoice_date',
                    'description': 'Invoice date',
                    'variable_type': 'date',
                    'sequence': 110,
                    'available_for': 'account.move',
                },
                {
                    'name': 'due_date',
                    'description': 'Due date',
                    'variable_type': 'date',
                    'sequence': 120,
                    'available_for': 'account.move',
                },
                {
                    'name': 'partner_name',
                    'description': 'Partner name',
                    'variable_type': 'text',
                    'sequence': 130,
                    'available_for': 'account.move',
                },
                {
                    'name': 'partner_address',
                    'description': 'Partner address',
                    'variable_type': 'text',
                    'sequence': 140,
                    'available_for': 'account.move',
                },
                {
                    'name': 'total_amount',
                    'description': 'Total amount',
                    'variable_type': 'currency',
                    'sequence': 150,
                    'available_for': 'account.move',
                },
            ])
        elif document_type == 'stock.picking':
            base_variables.extend([
                {
                    'name': 'picking_name',
                    'description': 'Picking number',
                    'variable_type': 'text',
                    'sequence': 100,
                    'available_for': 'stock.picking',
                },
                {
                    'name': 'picking_date',
                    'description': 'Picking date',
                    'variable_type': 'date',
                    'sequence': 110,
                    'available_for': 'stock.picking',
                },
                {
                    'name': 'picking_type',
                    'description': 'Picking type',
                    'variable_type': 'text',
                    'sequence': 120,
                    'available_for': 'stock.picking',
                },
                {
                    'name': 'partner_name',
                    'description': 'Partner name',
                    'variable_type': 'text',
                    'sequence': 130,
                    'available_for': 'stock.picking',
                },
                {
                    'name': 'partner_address',
                    'description': 'Partner address',
                    'variable_type': 'text',
                    'sequence': 140,
                    'available_for': 'stock.picking',
                },
                {
                    'name': 'total_items',
                    'description': 'Total number of items',
                    'variable_type': 'number',
                    'sequence': 150,
                    'available_for': 'stock.picking',
                },
            ])
        
        return base_variables 