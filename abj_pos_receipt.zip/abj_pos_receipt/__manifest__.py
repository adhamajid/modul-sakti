{
    'name': "POS Custom Receipt",
    'summary': "Module to customize the POS receipt printout template.",
    'description': """
        This module modifies the Point of Sale (POS) receipt template to match the desired format, including:
            - Removing VAT details from the receipt
            - Removing payment method display from the receipt
            - Removing "Powered by Odoo" from the receipt
            - Displaying unit price on the receipt
            - Removing logged-in user from the header
            - Standardizing font for header and footer
    """,
    'author': "Abajoo",
    'website': 'https://abajoo.co.id/',
    'license': 'LGPL-3',
    'category': "Point of Sale",
    'version': "1.0",
    'depends': ['point_of_sale'],
    'assets': {
        'point_of_sale._assets_pos': [
            'abj_pos_receipt/static/src/xml/order_receipt.xml',
            'abj_pos_receipt/static/src/xml/order_line.xml',
            'abj_pos_receipt/static/src/xml/receipt_header.xml',
        ],
    },
    'installable': True,
}
