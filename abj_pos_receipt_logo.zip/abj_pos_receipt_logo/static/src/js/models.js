/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { formatDate, formatDateTime } from "@web/core/l10n/dates";
import { parseUTCString } from "@point_of_sale/utils";

patch(PosStore.prototype, {
    getReceiptHeaderData(order) {
        var date;
        var res;
        if (order) {
            let date = "Invalid Date";
            if (order?.date_order) {
                let parsedDate = parseUTCString(order.date_order); // Konversi ke Date object

                // Format tanggal (DD/MM/YYYY) dan waktu (HH:mm:ss)
                let formattedDate = formatDate(parsedDate, { format: "dd/MM/yyyy" });
                let formattedTime = formatDateTime(parsedDate).split(" ")[1]; // Ambil hanya waktu

                date = `${formattedDate} ${formattedTime}`;
            }

            res = {
                ...super.getReceiptHeaderData(order),
                partner: order.partner_id,
                pos_reference: order.pos_reference,
                date: date,
            };
        } else {
            date = new Date().toLocaleString("id-ID");
            res = { ...super.getReceiptHeaderData(order) };
        }
        return res;
    },
});
