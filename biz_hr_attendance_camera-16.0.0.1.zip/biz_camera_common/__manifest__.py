# -*- coding: utf-8 -*-
{
    'name': 'Bizapps - Camera',
    'version': '16.0.0.1',
    'category': 'Tools',
    'description': "",
    'author': 'support@bizapps.vn',
    'website': 'https://www.bizapps.vn',
    'depends': ['base','biz_field_image_preview'],
    'data': [
        
    ],
    'installable': True,
    'application': True,
    "license": "OPL-1",
    'assets': {
        'web.assets_backend': [
            "biz_camera_common/static/src/lib/webcam.js",
            "biz_camera_common/static/src/css/web_widget_image_webcam.css",
            'biz_camera_common/static/src/xml/user_auth_dialog.xml',
            # 'biz_camera_common/static/src/xml/search_bar.xml',
        ],
    },
}
