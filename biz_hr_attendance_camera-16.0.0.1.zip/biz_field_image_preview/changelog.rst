15.1.0.2 - [FIX] print image
15.1.0.1 - [FIX] download preview image
