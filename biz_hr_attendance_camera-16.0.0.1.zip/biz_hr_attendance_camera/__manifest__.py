# -*- coding: utf-8 -*-

{
    'name': 'Biz - Attendances Using Camera',
    'version': '16.0.0.1',
    'category': 'Human Resources/Attendances',
    'summary': '',
    'description': "",
    "author": "support@bizapps.vn",
    "maintainer": "support@bizapps.vn",
    "contributors": ["support@bizapps.vn"],
    "website": "https://bizapps.vn/ung-dung",
    "company": 'Bizapps',
    "support": 'support@bizapps.vn',
    'depends': ['base','biz_camera_common','hr_attendance'],
    'data': [
        'views/hr_attendance_view.xml',
    ],

    'installable': True,
    'application': True,
    'assets': {
        'web.assets_backend': [
            'biz_hr_attendance_camera/static/src/**/*',
        ],
    },
    "images": ["static/description/background.jpg", ],
    "license": "OPL-1",
}
