from geopy.geocoders import Nominatim


def convert_coordinates_to_address(lat, lon):
    geolocator = Nominatim(user_agent="myapp")
    location = geolocator.reverse(f"{lat}, {lon}")

    return location.address