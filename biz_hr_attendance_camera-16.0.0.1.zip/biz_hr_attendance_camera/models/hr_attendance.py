# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, exceptions, _



class HrAttendance(models.Model):
    _inherit = "hr.attendance"

    checkin_image = fields.Binary("Check-in Image")
    checkin_latitude =  fields.Float('Check-in Latitude', digits=(10,7))
    checkin_longitude = fields.Float('Check-in Longitude', digits=(10,7))
    checkin_address = fields.Char('Check-in Address')

    checkout_image = fields.Binary("Check-out Image")
    checkout_latitude =  fields.Float('Check-out Latitude', digits=(10,7))
    checkout_longitude = fields.Float('Check-out Longitude', digits=(10,7))
    checkout_address = fields.Char('Check-out Address')




