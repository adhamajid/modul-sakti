# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import pytz
from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, exceptions, _
from odoo.tools import float_round
from .common import convert_coordinates_to_address


class HrEmployee(models.Model):
    _inherit = "hr.employee"


    def _attendance_action_change(self):
        context = dict(self._context)
        checked_in = False
        
        if self.attendance_state != 'checked_in':
            checked_in = True

        attendance = super(HrEmployee, self)._attendance_action_change()
        latitude = context.get('latitude', '')
        longitude = context.get('longitude', '')
        checkin_address = convert_coordinates_to_address(latitude, longitude)
        
        if checked_in:
            attendance.write({
                'checkin_image': context.get('img_data', ''),
                'checkin_latitude': latitude,
                'checkin_longitude': longitude,
                'checkin_address': checkin_address
            })
        else:
            attendance.write({
                'checkout_image': context.get('img_data', ''),
                'checkout_latitude': latitude,
                'checkout_longitude': longitude,
                'checkout_address': checkin_address
            })

        return attendance
    