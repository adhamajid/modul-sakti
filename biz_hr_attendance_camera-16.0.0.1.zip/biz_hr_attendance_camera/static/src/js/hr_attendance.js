odoo.define('biz_hr_attendance_camera.my_attendances', function (require) {
    "use strict";

    const MyAttendances = require('hr_attendance.my_attendances');
    var core = require('web.core');
    var qweb = core.qweb;
    var rpc = require('web.rpc');
    var Dialog = require('web.Dialog');
    var _t = core._t;
    const session = require('web.session');

    MyAttendances.include({
        // overide

        update_attendance: function() {
            var self = this,
                WebCamDialog = $(qweb.render("UserAuthDialog")), 
                img_data
            
            Webcam.set({
                width: 320,
                height: 240,
                dest_width: 320,
                dest_height: 240,
                image_format: 'jpeg',
                jpeg_quality: 90,
                force_flash: false,
                fps: 45,
                swfURL: '/biz_camera_common/static/src/js/webcam.swf',
            });

            rpc.query({
                model: 'ir.config_parameter',
                method: 'get_webcam_flash_fallback_mode_config',
            }).then(function(default_flash_fallback_mode) {
                if (default_flash_fallback_mode == 1) {
                    Webcam.set({
                        force_flash: true,
                    });
                }
            });

            var dialog = new Dialog(this, {
                title: _t("User Authentication"),
                size: 'large',
                $content: WebCamDialog,
                buttons: [{
                    text: _t("Take Snapshot"), 
                    classes: 'btn-primary take_snap_btn',
                    click: function () {
                        Webcam.snap( function(data) {
                            img_data = data;
                            // Display Snap besides Live WebCam Preview
                            WebCamDialog.find("#webcam_result").html('<img src="'+img_data+'"/>');
                        });
                        if (Webcam.live) {
                            // Remove "disabled" attr from "Save & Close" button
                            $('.save_close_btn').removeAttr('disabled');
                        }
                    }
                    },
                    // click: save
                    {
                        text: _t("Save & Close"), 
                        classes: 'btn-primary save_close_btn', 
                        close: true,
                        click: function () {
//                            if(!img_data){
//                                Webcam.snap( function(data) {
//                                    img_data = data;
//                                    // Display Snap besides Live WebCam Preview
//                                    WebCamDialog.find("#webcam_result").html('<img src="'+img_data+'"/>');
//                                });
//                            }
                            if (img_data === undefined){
                                self.displayNotification({ title: "No picture checkin/checkout", type: 'danger' });
                                return
                            }
                            var img_data_base64 = img_data.split(',')[1]
                            var context = session.user_context
                            context.img_data = img_data_base64

                            if (navigator.geolocation) {
                                navigator.geolocation.getCurrentPosition(function(position) {
                                    context.latitude = position.coords.latitude
                                    context.longitude = position.coords.longitude

                                    self._rpc({
                                        model: 'hr.employee',
                                        method: 'attendance_manual',
                                        args: [[self.employee.id], 'hr_attendance.hr_attendance_action_my_attendances'],
                                        context: context,
                                    })
                                    .then(function(result) {
                                        if (result.action) {
                                            self.do_action(result.action);
                                        } else if (result.warning) {
                                            self.displayNotification({ title: result.warning, type: 'danger' });
                                        }
                                    })
                                    .catch(function(error) {
                                        // Xử lý lỗi và hiển thị cảnh báo cho người dùng
                                        self.displayNotification({ title: "Không thể lấy được tọa độ", type: 'danger' });
                                    });
                                })
                            }else{
                                self.displayNotification({ title: "Trình duyệt không hỗ trợ định vị", type: 'danger' });
                            }
                        }
                    },
                    {
                        text: _t("Close"),
                        close: true
                    }]
                }).open();

                dialog.opened().then(function() {
                    Webcam.attach('#live_webcam');
                    $('.s').attr('disabled', 'disabled');
                    WebCamDialog.find("#webcam_result").html('<img src="/biz_camera_common/static/src/img/webcam_placeholder.png"/>');
                });
        },
    });

    return MyAttendances;
});