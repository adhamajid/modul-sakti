## Module <hide_menu_user>

#### 04.10.2024
#### Version 18.0.1.0.0
#### ADD

- Initial commit for Hide Any Menu User Wise

#### 11.06.2025
#### Version 18.0.2.0.0
#### UPDT

- Updated the module workflow, Only to type internal user can can hide the menu items.
