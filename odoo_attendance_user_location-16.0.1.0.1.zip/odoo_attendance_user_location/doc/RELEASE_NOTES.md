## Module <odoo_attendance_user_location>

#### 12.07.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Geolocation in HR Attendance

#### 21.09.2024
#### Version 16.0.1.0.1
#### UPDT

- Updated Geolocation location link in HR Attendance